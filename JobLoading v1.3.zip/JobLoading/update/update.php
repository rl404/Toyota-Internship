<html>
	<?php include "../header.php"; ?>
	<div class="ui container">
		<h1 class='ui center aligned dividing header' id='titleheader'>
			UPDATE WORK HOUR
		</h1>

		<div id='inputhourtable'>
			<?php include "updatetable.php"; ?>				
		</div>
		<div class='ui divider'></div>
		<div class='ui divider'></div>
	</div>
</body>
</html>