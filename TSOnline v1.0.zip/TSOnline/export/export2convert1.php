<?php
	

	echo "<iframe height=100% width=100%
	src='export2pdf.php?supplier=".$_POST['supplier']."'>";



	echo "</iframe>";

?>